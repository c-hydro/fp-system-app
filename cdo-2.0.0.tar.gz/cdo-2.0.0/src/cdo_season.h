#ifndef CDO_SEASON_H
#define CDO_SEASON_H

enum
{
  START_DEC,
  START_JAN
};

int get_season_start(void);

void get_season_name(const char *seas_name[]);

int month_to_season(int month);

#endif
