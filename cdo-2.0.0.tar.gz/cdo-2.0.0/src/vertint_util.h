#ifndef EXTRAPOLATION_OPTION_H
#define EXTRAPOLATION_OPTION_H

bool getenv_extrapolate(void);

#endif
