
/* sxxxYYYYMMDDhhmm0 */
#define DATE_LEN 31 /* YYYYMMDDhhmmss allocate DTLEN+1 !!!! */
#define SET_DATE(dtstr, date, time) (snprintf(dtstr, sizeof(dtstr), "%*ld%*d", DATE_LEN - 6, (long) date, 6, time))
#define DATE_IS_NEQ(dtstr1, dtstr2, len) (memcmp(dtstr1, dtstr2, len) != 0)
