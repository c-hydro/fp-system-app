void print_atts(int vlistID, int varOrGlobal, int natts, char *argument);
