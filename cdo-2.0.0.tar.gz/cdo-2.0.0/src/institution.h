#ifndef CDO_INSTITUTION
#define CDO_INSTITUTION

void define_institution(const char *instarg);

#endif
