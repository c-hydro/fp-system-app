/*
  This file is part of CDO. CDO is a collection of Operators to manipulate and analyse Climate model Data.

  Author: Uwe Schulzweida

*/
#ifndef EXPR_FUN_H
#define EXPR_FUN_H

#include <cstddef>
#include "field.h"

void fld_field_init(Field &field, size_t nmiss, double missval, size_t ngp, double *array, double *w);
void vert_weights(int zaxisID, size_t nlev, Varray<double> &weights);

#endif
