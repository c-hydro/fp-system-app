#ifndef TABLE_H
#define TABLE_H

int define_table(const char *tablearg);

#endif
