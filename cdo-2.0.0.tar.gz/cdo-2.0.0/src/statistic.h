#ifndef STATISTIC_H
#define STATISTIC_H

#include "varray.h"

namespace cdo
{

void eigen_solution_of_symmetric_matrix(Varray2D<double> &a, Varray<double> &eig_val, size_t n, const char *prompt);
void fft(double *real, double *imag, int n, int sign);
void ft_r(double *real, double *imag, int n, int sign, double *work_r, double *work_i);
double lngamma(double x);
double beta(double a, double b, const char *prompt);
double incomplete_gamma(double a, double x, const char *prompt);
double incomplete_beta(double a, double b, double x, const char *prompt);
double normal_density(double x);
double normal(double x, const char *prompt);
double normal_inv(double p, const char *prompt);
double student_t_density(double n, double x, const char *prompt);
double student_t(double n, double x, const char *prompt);
double student_t_inv(double n, double p, const char *prompt);
double chi_square_density(double n, double x, const char *prompt);
double chi_square(double n, double x, const char *prompt);
double chi_square_inv(double n, double p, const char *prompt);
void chi_square_constants(double n, double p, double *c1, double *c2, const char *prompt);
double beta_distr_density(double a, double b, double x, const char *prompt);
double beta_distr(double a, double b, double x, const char *prompt);
double beta_distr_inv(double a, double b, double p, const char *prompt);
void beta_distr_constants(double a, double b, double p, double *c1, double *c2, const char *prompt);
double fisher(double m, double n, double x, const char *prompt);

// make parallel eigen solution accessible for eigen value computation in EOF3d.c
void parallel_eigen_solution_of_symmetric_matrix(Varray2D<double> &M, Varray<double> &A, size_t n, const char func[]);

}  // namespace cdo

#endif
