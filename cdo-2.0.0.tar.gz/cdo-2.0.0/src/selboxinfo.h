#ifndef SELBOXINFO_H
#define SELBOXINFO_H

struct SelboxInfo
{
  int gridtype = -1;
  int gridID1 = -1, gridID2 = -1;
  std::vector<long> cellidx;
  long nvals = 0;
  long lat1 = 0, lat2 = 0, lon11 = 0, lon12 = 0, lon21 = 0, lon22 = 0;
};

void genlonlatbox(int argc_offset, int gridID, SelboxInfo &sbox);
void genindexbox(int argc_offset, int gridID1, SelboxInfo &sbox);

#endif
