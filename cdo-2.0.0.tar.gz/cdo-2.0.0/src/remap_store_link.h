/*
  This file is part of CDO. CDO is a collection of Operators to manipulate and analyse Climate model Data.

  Author: Uwe Schulzweida

*/
#ifndef REMAP_STORE_LINK_H
#define REMAP_STORE_LINK_H

#include <vector>

// Predeclarations
struct RemapVars;

struct Addweight
{
  size_t add;
  double weight;
};

struct Addweight4
{
  size_t add;
  double weight[4];
};

struct WeightLinks
{
  size_t nlinks;
  size_t offset;
  Addweight *addweights;
};

struct WeightLinks4
{
  size_t nlinks;
  size_t offset;
  Addweight4 *addweights;
};

void weight_links_alloc(size_t numNeighbors, size_t gridSize, std::vector<WeightLinks> &weightLinks);
void weight_links_4_alloc(size_t gridSize, std::vector<WeightLinks4> &weightLinks);
void store_weightlinks(int lalloc, size_t numWeights, size_t *srch_add, double *weights, size_t cell_add,
                       std::vector<WeightLinks> &weightLinks);
void store_weightlinks_bicubic(size_t *srch_add, double (&weights)[4][4], size_t cell_add, std::vector<WeightLinks4> &weightLinks);
void weight_links_to_remap_links(int lalloc, size_t gridSize, std::vector<WeightLinks> &weightLinks, RemapVars &rv);
void weight_links_4_to_remap_links(size_t gridSize, std::vector<WeightLinks4> &weightLinks, RemapVars &rv);
void sort_weights(size_t numWeights, size_t *src_add, double *weights);
void sort_weights_n4(size_t *src_add, double *weights);
void sort_weights_bicubic(size_t *src_add, double (&weights)[4][4]);

#endif /* REMAP_STORE_LINK */
