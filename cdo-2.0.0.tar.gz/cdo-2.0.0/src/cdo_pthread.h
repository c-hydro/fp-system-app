#ifndef CDO_PTHREAD_H
#define CDO_PTHREAD_H

void print_pthread_info();

#endif
